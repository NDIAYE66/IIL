from __future__ import division, print_function, absolute_import

from functools import reduce
from operator import mul

import pdb
import math
import torch
import  torch.nn as nn
import torch.nn.functional as F
import torch.optim as optim
from torch.autograd import Variable
import math
from utils import preprocess_gradients
from torch_geometric.nn import GCNConv


class MetaLSTMCell(nn.Module):
    ''' C_t = f_t * C_{t-1} + i_t * \tilde{C_t}'''

    def __init__(self, input_size, hidden_size, n_learner_params):
        super(MetaLSTMCell, self).__init__()
        """Args:
           input_size(int): cell input size, defaut = 20
           hidden_size(int): should be 1
           n_learner_params(int): number of learner's parameters
        """

        self.input_size = input_size
        self.hidden_size = hidden_size
        self.n_learner_params = n_learner_params
        self.WF = nn.Parameter(torch.Tensor(input_size + 62, hidden_size))
        self.WI = nn.Parameter(torch.Tensor(input_size + 62, hidden_size))
        self.cI = nn.Parameter(torch.Tensor(n_learner_params, 1))
        self.bI = nn.Parameter(torch.Tensor(1, hidden_size))
        self.bF = nn.Parameter(torch.Tensor(1, hidden_size))

        self.reset_parameters()

    def reset_parameters(self):
        for weight in self.parameters():
            nn.init.uniform_(weight, -0.01, 0.01)

        """ want inital forget value to be high and input  value to be low so
            that model starts with gradient descent
        """
        nn.init.uniform_(self.bF, 4, 6)
        nn.init.uniform_(self.bI, -5, -4)

    def init_cI(self, flat_params):
        self.cI.data.copy_(flat_params.unsqueeze(1))

    def forward(self, inputs, hx=None):
        """

        :param input = [x_all, grad]: x_all(torch.Tensor of size [n_learner_params, input size]):output
        from previous LSTM
        grad (torch.Tensor of size [n_learner_params]): gradient from learner
        :param hx: hx = [f_prev, i_prev, c_prev]:
                f (torch.Tensor of size [n_learner_params, 1]): forget gate
                i (torch.Tensor of size [n_learner_params, 1]): input gate
                c (torch.Tensor of size [n_learner_params, 1]): flattened learner parameters

        """

        x_all, grad = inputs
        batch, _ = x_all.size()

        if hx is None:
            f_prev = torch.zeros((batch, self.hidden_size)).to(self.WF.device)
            i_prev = torch.zeros((batch, self.hidden_size)).to(self.WI.device)
            c_prev = self.cI
            hx = [f_prev, i_prev, c_prev]

        f_prev, i_prev, c_prev = hx

        # f_t = sigmoid(W_f * [grad_t, loss_t, theta_{t-1}, f_{t-1}] + b_f)
        f_next = torch.mm(torch.cat((x_all, c_prev,f_prev), 1), self.WF) + self.bF.expand_as(f_prev)
        # i_t = sigmoid(W_i * [grad_t, loss_t, theta_{t-1}, i_{t-1}] + b_i)
        i_next = torch.mm(torch.cat((x_all, c_prev, i_prev), 1), self.WI) + self.bI.expand_as(i_prev)
        # next cell/params
        c_next = torch.sigmoid(f_next).mul(c_prev) - torch.sigmoid(i_next).mul(grad)

        return c_next, [f_next, i_next, c_next]

    def extra_repr(self):
        s = '{input_size}, {hidden_size}, {n_learner_params}'
        return s.format(**self.__dict__)

class Metalearner(nn.Module):
    def __init__(self, c_feat, c_hid, n_learner_params):
        super(Metalearner, self).__init__()
        """Args:
            input_size (int): for the first LSTM layer, default = 322
            hidden_size (int): for the first LSTM layer, default = 20
            n_learner_params (int): number of learner's parameters
        """
        self.lstm = nn.LSTMCell(input_size=c_feat, hidden_size=c_hid)
        self.metalstm = MetaLSTMCell(input_size=c_feat, hidden_size=1,
                                     n_learner_params=n_learner_params)

    def forward(self, inputs, hs=None):
        """Args:
            inputs = [loss, grad_prep, grad]
                loss (torch.Tensor of size [1, 2])
                grad_prep (torch.Tensor of size [n_learner_params, 2])
                grad (torch.Tensor of size [n_learner_params])
            hs = [(lstm_hn, lstm_cn), [metalstm_fn, metalstm_in, metalstm_cn]]
        """
        loss, grad_prep, grad = inputs
        loss = loss.expand_as(grad_prep)
        inputs = torch.cat((loss, grad_prep), 1)

        if hs is None:
            hs = [None, None]

        lstmhx, lstmcx = self.lstm(inputs, hs[0])
        flat_learner_usqzd, metalstm_hs = self.metalstm([lstmhx, grad], hs[1])

        return flat_learner_usqzd.squeeze(), [(lstmhx, lstmcx), metalstm_hs]



class Inner_learner(nn.Module):
    def __init__(self, c_feat,c_hid, num_c,dropout, window=7):
        super(Inner_learner, self).__init__()

        self.c_feat = c_feat
        self.c_hid = c_hid
        self.window = window
        self.n_layer = 2
        self.conv = GCNConv(c_feat, c_hid)
        self.bn = nn.BatchNorm1d(c_hid)
        self.dropout = nn.Dropout(dropout)
        self.num_c = num_c
        self.cout = 1

        self.relu = nn.ReLU()

        self.lstm1 = nn.LSTM(self.c_hid, self.c_hid , num_layers=1)
        # self.lstm2 = nn.LSTM(c_hid, c_hid)

        self.fc = nn.Linear(c_hid, self.cout)

        # self.cell = (nn.Parameter(nn.init.xavier_uniform(torch.Tensor(self.n_layer, self.batch_size, self.c_hid).type(torch.FloatTensor).cuda()),requires_grad=True))

    def forward(self,adj, feat):
        # lst = list()
        weight = adj.coalesce().values()
        adj = adj.coalesce().indices()

        # print(f'feat shape{feat.shape}')
        feat = self.relu(self.conv(feat,adj, edge_weight= weight))
        feat = self.bn(feat)
        feat = self.dropout(feat)

        # print(f'feat shape{feat.shape}')
        feat = feat.view(-1, self.window,self.num_c, feat.size(1))
        # print(f'feat shape{feat.shape}')
        feat = torch.transpose(feat, 0, 1)
        # print(f'feat shape{feat.shape}')
        feat = feat.contiguous().view(self.window, -1, feat.size(3))
        # print(f'feat shape{feat.shape}')
        feat, (hn,cn) = self.lstm1(feat)
        #cn: hid_sz * batch; feat: seq_len * hid_size * batch

        out = self.relu(self.fc(feat)).squeeze()



        return out[-1]

    def get_flat_params(self):
        return torch.cat([p.view(-1) for p in self.parameters()], 0)

    def copy_flat_params(self, cI):
        idx = 0
        for p in self.parameters():
            plen = p.view(-1).size(0)
            p.data.copy_(cI[idx: idx + plen].view_as(p))
            idx += plen

    def transfer_params(self,learner_w_grad, cI):
        self.load_state_dict(learner_w_grad.state_dict())
        # replace nn.Parameters with tensors from cI (NOT nn.Parameters anymore)
        #own_state = self.state_dict()

        #print(f'Keys: {self.state_dict().keys()}')

        idx = 0
        for m in self.modules():
            # print(f'the parameters {list(m.named_parameters())}')
            if isinstance(m, GCNConv):# or isinstance(m, nn.LSTM) or isinstance(m, nn.Linear) or isinstance(m, nn.BatchNorm1d):
                #print(f'Transfer for Conv module')
                setattr(m, 'conv.lin.weight', cI[idx:idx+len(list(m.named_parameters('conv.lin.weight')))])
            
                #idx += len(list(m.named_parameters('conv.lin.weight')))
                if m.named_parameters('conv.lin.bias') is not None:
                    setattr(m, 'conv.lin.bias', cI[idx:idx + len(list(m.named_parameters('conv.lin.bias')))])
                
                    #idx += len(list(m.named_parameters('conv.lin.bias')))
            #if isinstance(m, nn.BatchNorm1d):
                #print(f'Transfer for BatchNorm module')
                #setattr(m, 'bn.weight', cI[idx:idx + len(list(m.named_parameters('bn.weight')))])

                #idx += len(list(m.named_parameters('bn.weight')))
                #if m.named_parameters('bn.bias') is not None:
                    #setattr(m, 'bn.weight', cI[idx:idx + len(list(m.named_parameters('bn.weight')))])
                   
                    #idx += len(list(m.named_parameters('bn.weight')))
            if isinstance(m, nn.LSTM):
                #print(f'Transfer for LSTM module')
                setattr(m, 'lstm1.weight_hh_l0', cI[idx:idx + len(list(m.named_parameters('lstm1.weight_hh_l0')))])
            
                idx += len(list(m.named_parameters('lstm1.weight_hh_l0')))
                if m.named_parameters('lstm1.bias_hh_l0') is not None:
                    setattr(m, 'lstm1.bias_hh_l0', cI[idx:idx + len(list(m.named_parameters('lstm1.bias_hh_l0')))])
                    
                    idx += len(list(m.named_parameters('lstm1.bias_hh_l0')))
            if isinstance(m, nn.Linear):
                #print(f'Transfer for Linear module')
                setattr(m, 'fc.weight', cI[idx:idx + len(list(m.named_parameters('fc.weight')))])
            
                idx += len(list(m.named_parameters('fc.weight')))
                if m.named_parameters('fc.bias')is not None:
                    setattr(m, 'fc.bias', cI[idx:idx + len(list(m.named_parameters('fc.bias')))])
                  
                    idx += len(list(m.named_parameters('fc.bias')))


    def reset_batch_stats(self):
        for m in self.modules():
            if isinstance(m, nn.BatchNorm1d):
                m.reset_running_stats()
