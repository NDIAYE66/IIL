import time
import argparse
import networkx as nx
import numpy as np
import scipy.sparse as sp
from sklearn import preprocessing
import os
import pandas as pd

from math import ceil
from datetime import date, timedelta

import itertools
import pandas as pd
from sklearn.preprocessing import MinMaxScaler
import numpy as np

import os

from functools import reduce
from utils import generate_graphs_tmp


step = 5
start_exp = 15
window = 7

os.chdir("../data")
os.chdir("Florida")
labels = pd.read_csv("florida_labels.csv")
# labels.loc[labels["City"]=="Alachua","City"] = "Alachua"
# labels.loc[labels["City"]=="Alafaya","City"] = "Alafaya"
# labels.loc[labels["City"]=="Alford","City"] = "Alford"
# labels.loc[labels["City"]=="Altamonte Springs","City"] = "Altamonte Springs"
# del labels["id"]
labels = labels.set_index("City")

sdate = date(2020, 7, 1)
edate = date(2020, 9, 30)
delta = edate - sdate
dates = [sdate + timedelta(days=i) for i in range(delta.days+1)]
dates = [str(date) for date in dates]


Gs = generate_graphs_tmp(dates,"FL")
#labels = labels[,:]
labels = labels.loc[list(Gs[0].nodes()),:]


labels = labels.loc[labels.sum(1).values>10,dates]    
gs_adj = [nx.adjacency_matrix(kgs).toarray().T for kgs in Gs]



y = list()
for i,G in enumerate(Gs):
    y.append(list())
    for node in G.nodes():
        y[i].append(labels.loc[node,dates[i]])

nodez = Gs[0].nodes()
main = pd.DataFrame(labels.loc[nodez,labels.columns[start_exp]:].mean(1))
main.columns = ["avg_cases"]
main["cases"] = pd.DataFrame(labels.loc[nodez,labels.columns[start_exp]:].sum(1))
main = main.reset_index()


#df = pd.DataFrame(labels.iloc[:,start_exp:].mean(1))
#df.columns = ["avg_cases"]
#df["cases"] = pd.DataFrame(labels.iloc[:,start_exp:].sum(1))
#df = df.reset_index()

os.chdir("/output")
x0 = []
x1 = []
x2 = []
x3 = []
x4 = []
for i in range(15,79):
    try:
        x0.append(pd.read_csv("out_FL_"+str(i)+"_0.csv"))
        #df.drop(df.columns[0],1))
    except:
        print(i)

    try:
        x1.append(pd.read_csv("out_FL_"+str(i)+"_1.csv"))
        #df.drop(df.columns[0],1))
    except:
        print(i)

    try:
        x2.append(pd.read_csv("out_FL_"+str(i)+"_2.csv"))
        #df.drop(df.columns[0],1))
    except:
        print(i)
    try:
        x3.append(pd.read_csv("out_FL_"+str(i)+"_3.csv"))
        #df.drop(df.columns[0],1))
    except:
        print(i)
    try:
        x4.append(pd.read_csv("out_FL_"+str(i)+"_4.csv"))
        #df.drop(df.columns[0],1))
    except:
        print(i)
        


n = x0[0]["n"]

cnt = 0
pds = []
pds_r = []
for i in range(0,len(x4)):
    tmpx = [x0[i],x1[i],x2[i],x3[i],x4[i]] # step = 5
    d = reduce(lambda p, l: p.add(l, fill_value=0), tmpx)
    del d["n"]
    d = d/step
    par = d["l"].copy()
    par[par<1]=1
    pds.append(abs(d["o"]-d["l"]))
    pds_r.append(abs(d["o"]-d["l"])/par)

pds_r = reduce(lambda p, l: p.add(l, fill_value=0), pds_r)/i
pds = reduce(lambda p, l: p.add(l, fill_value=0), pds)/i
df = pd.DataFrame({"relative":pds_r.values,"real":pds.values,"City":n })


tmp = df.merge(main,on='City')
tmp.to_csv("FL_map_plot_"+str(step)+".csv")


